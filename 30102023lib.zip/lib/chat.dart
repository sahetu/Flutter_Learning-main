import 'package:flutter/material.dart';

class ChatDemo extends StatefulWidget{

  @override
  ChatApp createState() => ChatApp();
}

class ChatApp extends State<ChatDemo>{
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    //throw UnimplementedError();
    return Scaffold(
      body: Container(
        color:Colors.amber.shade200,
      ),
    );
  }
}