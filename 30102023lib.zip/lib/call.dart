import 'package:flutter/material.dart';

class CallDemo extends StatefulWidget{

  @override
  CallApp createState() => CallApp();
}

class CallApp extends State<CallDemo>{
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    //throw UnimplementedError();
    return Scaffold(
      body: Container(
        color:Colors.red.shade200,
      ),
    );
  }
}